/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: sketch.js                              *
 * Author: Dr. Evil!                              *
 * Date: 10/02/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Sweetie Sorter App                             *
 **************************************************/
let classifier;
let can;
let video;
let data = [];
//let modelURL = '<MODEL>';
let modelURL = 'https://teachablemachine.withgoogle.com/models/hi-QIF4Ck/';
let label = "waiting......";
//FOR HD scl = 1.5
//FOR UHD scl 2.5
let scl = 1.5;
//let scl = 2.5

function preload() {
  classifier = ml5.imageClassifier(modelURL+"model.json",{ flipped: true });
}

function mousePressed() {
    console.log(data);
}

function keyPressed() {
  if (key == 'f') {
    if (fullscreen()) {
      fullscreen(false);
    } else {
      fullscreen(true);
    }
  }
}

function classifyVideo() {
  classifier.classify(video, gotResults);
}

function gotResults(error, results) {
  data = results;
  if (results[0].confidence < 0.9) {
    label = "Not Sure!";
  } else {
    label = results[0].label;
  }
  classifyVideo();
}

function setup() {
  scale(scl);
  can = createCanvas(640*scl, 480*scl);
//  can = createCanvas(640, 480);
  centerCanvas();
  video = createCapture(VIDEO, { flipped: true });
  video.hide();
  classifyVideo();
}

function centerCanvas() { 
    let x = (windowWidth - width) / 2; 
    let y = (windowHeight - height) / 2; 
    can.position(x, y); 
} 
    
function windowResized() { 
    centerCanvas(); 
}

function draw() {
  scale(scl);
  background(220);
  image(video, 0, 0, width/scl, height/scl);

  rectMode(LEFT);
  fill(0);
  rect(0, (height/scl) - (75*scl), width*scl, 50*scl);
  textSize(32);
  fill(255);
  textAlign(CENTER, CENTER);
  noStroke();
  text(label, (width/scl) / 2, (height/scl) - (50*scl));
}
