let classifier;
let can;
let video;
let data = [];
let modelURL = '<MODEL>';
//let modelURL = 'https://teachablemachine.withgoogle.com/models/hi-QIF4Ck/';
let label = "waiting......";

function preload() {
  classifier = ml5.imageClassifier(modelURL+"model.json",{ flipped: true });
}

function mousePressed() {
    console.log(data);
}

function classifyVideo() {
  classifier.classify(video, gotResults);
}

function gotResults(error, results) {
  data = results;
  if (results[0].confidence < 0.9) {
    label = "Not Sure!";
  } else {
    label = results[0].label;
  }
  classifyVideo();
}

function setup() {
  can = createCanvas(640, 460);
  centerCanvas();
  video = createCapture(VIDEO, { flipped: true });
  video.hide();
  classifyVideo();
}

function centerCanvas() { 
    let x = (windowWidth - width) / 2; 
    let y = (windowHeight - height) / 2; 
    can.position(x, y); 
} 
    
function windowResized() { 
    centerCanvas(); 
}

function draw() {
  background(220);
  image(video, 0, 0, width, height);

  rectMode(CENTER);
  fill(0);
  rect(width / 2, height - 50, width, 50);
  textSize(32);
  fill(255);
  textAlign(CENTER, CENTER);
  noStroke();
  text(label, width / 2, height - 50);
}
