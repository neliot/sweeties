let classifier;
let canvas;
let video;
let data = [];
let label = "waiting...";

function preload() {
  classifier = ml5.imageClassifier(
    "<MODEL>",
    { flipped: true }
  );
}

function mousePressed() {
    console.log(data);
}

function gotResults(results) {
  data = results;
  if (data[0].confidence < 0.9) {
    label = "Not Sure!"
  } else {
    label = data[0].label;
  }
}

function setup() {
  canvas = createCanvas(640, 480);
  centerCanvas();
  video = createCapture(VIDEO, { flipped: true });
  video.hide();
  classifier.classifyStart(video, gotResults);
}

function centerCanvas() { 
    let x = (windowWidth - width) / 2; 
    let y = (windowHeight - height) / 2; 
    canvas.position(x, y); 
  } 
    
function windowResized() { 
    centerCanvas(); 
}

function draw() {
  background(220);
  image(video, 0, 0, width, height);

  rectMode(CENTER);
  fill(0);
  rect(width / 2, height - 50, width, 50);
  textSize(32);
  fill(255);
  textAlign(CENTER, CENTER);
  noStroke();
  text(label, width / 2, height - 50);
}
